% calculate transition matrix
% need to calculate (z,e) -> (z',e') 4 by 4 matrix
function [PP,Pi_ss,series_state]=transition_matrix(flag,T)
%% parameter
z_g=1.01;
z_b=0.99;
u_g=0.04;
u_b=0.1;


%% first to calcuate Uss 
% the average duration for good and bad time is 8 quarters ,N is the period
% EN=8 -> \sum n*(g)^n*(1-g)=8  expectation for consecutive good period is
% expectation of this is 1/(1-g)=8
pi_gg=1-1/8;
pi_bb=1-1/8;
pi_gb=1-pi_gg;
pi_bg=1-pi_bb;


%% second to calculate conditional matrix for empolyment
% conditional on gg bb which are   00  01 10 11
% the average duration of an unemployment spell is 1.5 quarters in good
% times and 2.5 quarters in bad times.
pi_gg00_c=(1-1/1.5);
pi_bb00_c=(1-1/2.5);

% according to the exrepssion
% pi_ss00+pi_ss01=pi_ss10+pi_ss11=pi_ss
% u_s * pi_ss00/pi_ss+(1-u_s)*pi_ss10/pi_ss=u_s'
% pi_gb00/pi_gb=1.25pi_bb00/pi_bb 
% pi_bg00/pi_bg=0.75*pi_gg00/pi_gg


% for pi_gg01, pi_bb01
pi_gg01_c=1-pi_gg00_c;
pi_bb01_c=1-pi_bb00_c;

% for pi_gg10, pi_bb10
pi_gg10_c=(u_g-u_g*pi_gg00_c)/(1-u_g);
pi_bb10_c=(u_b-u_b*pi_bb00_c)/(1-u_b);

% for pi_gg11 pi_bb11
pi_gg11_c=1-pi_gg10_c;
pi_bb11_c=1-pi_bb10_c;


% conditional on gb gb which are   00  01 10 11
pi_gb00_c=1.25*pi_bb00_c;
pi_bg00_c=0.75*pi_gg00_c;

% for pi_gg01, pi_bb01
pi_gb01_c=1-pi_gb00_c;
pi_bg01_c=1-pi_bg00_c;

% for pi_gg10, pi_bb10
pi_gb10_c=(u_b-u_g*pi_gb00_c)/(1-u_g);
pi_bg10_c=(u_g-u_b*pi_bg00_c)/(1-u_b);

% for pi_gg11 pi_bb11
pi_gb11_c=1-pi_gb10_c;
pi_bg11_c=1-pi_bg10_c;


%% the matrix
Pi_ss=[pi_gg,1-pi_gg;1-pi_bb,pi_bb];
% Pi_ss

Pi_gg_ee=[pi_gg00_c,pi_gg01_c;
                 pi_gg10_c,pi_gg11_c];
             
% Pi_gg_ee

Pi_bb_ee=[pi_bb00_c,pi_bb01_c;
                 pi_bb10_c,pi_bb11_c];

% Pi_bb_ee

Pi_bg_ee=[pi_bg00_c,pi_bg01_c;
                 pi_bg10_c,pi_bg11_c];

% Pi_bg_ee

Pi_gb_ee=[pi_gb00_c,pi_gb01_c;
                 pi_gb10_c,pi_gb11_c];
             
% Pi_gb_ee

%% the final matrix
% g0 g1 b0 b1
PP=zeros(4,4);
PP(1,1)=pi_gg*pi_gg00_c;
PP(1,2)=pi_gg*pi_gg01_c;
PP(1,3)=pi_gb*pi_gb00_c;
PP(1,4)=pi_gb*pi_gb01_c;

PP(2,1)=pi_gg*pi_gg10_c;
PP(2,2)=pi_gg*pi_gg11_c;
PP(2,3)=pi_gb*pi_gb10_c;
PP(2,4)=pi_gb*pi_gb11_c;


PP(3,1)=pi_bg*pi_bg00_c;
PP(3,2)=pi_bg*pi_bg01_c;
PP(3,3)=pi_bb*pi_bb00_c;
PP(3,4)=pi_bb*pi_bb01_c;

PP(4,1)=pi_bg*pi_bg10_c;
PP(4,2)=pi_bg*pi_bg11_c;
PP(4,3)=pi_bb*pi_bb10_c;
PP(4,4)=pi_bb*pi_bb11_c;


%% next is the simulation
if flag==1
rng(1)
epsi=rand(T);
sc=[pi_gg,pi_bb];
% initialize vector
shckreal=ones(T,1);
% initial condition
shckreal(1)=1;
for j=2:T
    if shckreal(j-1)==1
    if epsi(j)<=sc(shckreal(j-1))
    shckreal(j)=shckreal(j-1);
    else
        shckreal(j)=2;
    end
    end
    % now other case
    if shckreal(j-1)==2
    if epsi(j)<=sc(shckreal(j-1))
    shckreal(j)=shckreal(j-1);
    else
        shckreal(j)=1;
    end
    end
end

series_state=shckreal;
else
    series_state=0;
end



