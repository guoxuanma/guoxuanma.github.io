function V=bellman(k_t,k,K_bar,j,kk,lin_V_temp,cubic_fit_g0,cubic_fit_g1,cubic_fit_b0,cubic_fit_b1,z,e,PP)
% V_temp is n_k, n_K, z, e
z_g=1.01;
z_b=0.99;
u_g=0.04;
u_b=0.1;
% theta follows ar(1) process
delta=0.025; % 10% peryear
alpha = 0.36; % capital share 
beta =0.99; % time discount factor
l=0.3271;
% l=1;
z_s=[z_g,z_b];
e_s=[0,1];
u_s=[u_g,u_b];


% consumption


r=z_s(z)*alpha*(K_bar/(l.*(1-u_s(z))))^(alpha-1);
w=z_s(z)*(1-alpha)*(K_bar/(l.*(1-u_s(z))))^(alpha);
c=r*k+w*l*e_s(e)+(1-delta)*k-k_t;
if c<=0
    uc=log(10^(-40));
else
    uc=log(c);
end

if z==1 && e==1
    state=1;
else if z==1 && e==2
        state=2;
    else if z==2 && e==1
            state=3;
        else if z==2 && e==2
                state=4;
            end
        end
    end
end

if k_t<kk(end)
    % near zeros use liner interp
    V=uc+beta*(interp1q(kk,lin_V_temp(:,j,1,1),k_t)*PP(state,1)+interp1q(kk,lin_V_temp(:,j,1,2),k_t)*PP(state,2)+interp1q(kk,lin_V_temp(:,j,2,1),k_t)*PP(state,3)+interp1q(kk,lin_V_temp(:,j,2,2),k_t)*PP(state,4)); 
else
% V=uc+beta*(ppval(cubic_fit_g0,k_t)*PP(state,1)+ppval(cubic_fit_g1,k_t)*PP(state,2)+ppval(cubic_fit_b0,k_t)*PP(state,3)+ppval(cubic_fit_b1,k_t)*PP(state,4));
V=uc+beta*(ppval(cubic_fit_g0,k_t)*PP(state,1)+ppval(cubic_fit_g1,k_t)*PP(state,2)+ppval(cubic_fit_b0,k_t)*PP(state,3)+ppval(cubic_fit_b1,k_t)*PP(state,4));
end
V=-V;
