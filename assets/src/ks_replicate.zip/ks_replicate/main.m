% KS model 
% procedure
% set up parameter
% calculate transition matrix
% do value function iteration 
% deal with interpolation
% do the simulation
% computing the regression 
% test the converging criterion
% update and compute again

% finally i found the problem 
% interpolation problem 
% because in the k=0, ln0 -> very very small, the interpolation is not function properly in that sense. 
% need two kinds of interpolation, first is linear around zero(k=0) and
% cubic(spline) above zero(K>0)


clc
clear

%% parameter
% theta follows ar(1) process
delta=0.025; % 10% peryear
alpha = 0.36; % capital share 
beta =0.99; % time discount factor

% aggregate shock 
z_g=1.01;
z_b=0.99;
u_g=0.04;
u_b=0.1;



% H
a_0=0.09487;
a_1=0.96242;
b_0=0.08482 ;
b_1=0.96433 ;
H=[a_0,a_1;
      b_0,b_1];
l=0.3271;
% l=1;

rng(1) % set the random seed
% exogenous state dimension
n_z=2;
n_e=2;
%% calculate transition matrix
% the average duration for good and bad time is 8 quarters ,N is the period
% EN=8 -> \sum n*(g)^n*(1-g)=8  expectation for consecutive good period is
% expectation of this is 1/(1-g)=8
flag=0;
T_disgard=1000;
T=10;
[PP,Pi_ss,~]=transition_matrix(flag,T);
% PP is the transition matrix which is g0 g1 b0 b1


%% specify the state sapce of capital k
% given the liner form of aggregate capital, calculate the steady state for
% aggregate capital (average)
% since this heter problem is not appropriate to apply euler equation for 
% computing steady state capital we just let individual capital
% =[0,2*k_bar]
K_bar_g = exp(a_0/(1-a_1));
K_bar_b = exp(b_0/(1-b_1));

% steady state

% aggreagate capital stock space
K_bar_l  = K_bar_b*0.5;
K_bar_h  = K_bar_g*1.4;
% linspace
% set grid points size 
N_K_bar=4;
step=(K_bar_h-K_bar_l)/N_K_bar;
K_bar_origin=(K_bar_l:step:K_bar_h)';
n_K=length(K_bar_origin); % real size of the aggregate capital space 
K_bar=K_bar_origin';



N_k=100;

cut_point=0.01;
lambda=2;
step2=(lambda*K_bar_h-cut_point)/(N_k/2);
% k_origin=[0:(cut_point/(N_k/2)):cut_point,cut_point+step2:step2:lambda*K_bar_h];
k_origin2=linspace(0.1,lambda*K_bar_h,N_k/2);
k_origin1=linspace(0,0.095,N_k/2);
k_origin=[k_origin1,k_origin2];

n_k=length(k_origin);
k=k_origin';
k_t=k;
k_1=k_origin1';
k_2=k_origin2';



 %% value function iteration with interpolation 
 V_temp=zeros(n_k,n_K,n_z,n_e); % first is capital second is theta
 V_temp2=zeros(n_k,n_K,n_z,n_e); % first is capital second is theta
 
 VV  = zeros(n_k,n_K,n_z,n_e); % value function first is capital second is theta
 r=zeros(n_K,1,2); % last dimension is z z=1 represent good z=2 represent bad 
 w=zeros(n_K,1,2);% last dimension is z
 K_bar_t=zeros(n_K,1);
 k_opt_t= zeros(n_k,n_K,n_z,n_e);
 k_opt= zeros(n_k,n_K,n_z,n_e);
%  r_b=zeros(n_K,1);
%  w_b=zeros(n_K,1);
 temp_V_Kbar=zeros(n_k,n_K,n_z,n_e);
 
 K_opt= zeros(n_k,n_K,n_z,n_e); 
 toler=0.000001;  % tolerance for iteration;
 U=zeros(n_k,n_K);
 
 n_k2=N_k/2+1:N_k;
 n_k1=1:N_k/2;
 
e_s=[0,1];
tic
 for t= 1:200 % how many iteration for VFI
     
     if t ==1  % inital state
         % 4 state 
         % z=good 
         r(:,:,1)=z_g.*alpha.*(K_bar./(l.*(1-u_g))).^(alpha-1);
         w(:,:,1)=z_g.*(1-alpha).*(K_bar./(l.*(1-u_g))).^(alpha);
         
         r(:,:,2)=z_b.*alpha.*(K_bar./(l.*(1-u_b))).^(alpha-1);
         w(:,:,2)=z_b.*(1-alpha).*(K_bar./(l.*(1-u_b))).^(alpha);         
         for zz=1:2
             for ee=1:2
             k_opt_t(:,:,zz,ee)=k*ones(1,n_K);
             temp_c=k*r(:,:,zz)'+ones(n_k,1)*w(:,:,zz)'.*e_s(ee).*l+(1-delta).*k*ones(1,n_K);
             [row,col]=find(temp_c>0);
             U(row,col)=log(temp_c(row,col));
             [row,col]=find(temp_c<=0);
             U(row,col)=log(10^-40);
         V_temp(:,:,zz,ee)=U;
             end
         end
         
     end
     
     % formal loop
     % what the f**k, value function iteration and decision rules has
     % different gird points 
     % for VFI : K_bar : 6 k : 100, many grid near 0 
     % for decision rule : K_bar : 50, K:400
     
     % given z e  four different state,
     % for VFI
     % 1> calculate V(:,:,z,e) for for value function (which we can get from perious iteration)
     % 2> calculate K_bar_t using the law of motion 
     % 3> use polinominal interpolation to update V(:,:,z,e)
     % 4> use fminsearch compute k' and use cubic spline to get
     % interpolation value for k' and new value function 
     % for decision rule
     % when we done the value function optimization for each loop,
     % we can utilize the cubic and polinomial interpolation to just
     % interpolation again for decision rules point and find the next
     % optimal choice
     % if point not in the VFI point,use bilinear interpolation (interp2 in matlab )
     % only need to calculate once before simulation 
     
         for zz = 1:2
                 for ee = 1:2

                     % calculate the law of motion for K_bar'
                     K_bar_t(:,1)=exp(H(zz,1)+H(zz,2)*log(K_bar));

                     % update the value function by K_bar
                     % for each k 
                     for i=1:n_k

                     p_fit= polyfit(K_bar,V_temp(i,:,zz,ee),n_K-1); % make sure the dimension is consistent 
                     V_k_bar_polyfit=polyval(p_fit,K_bar_t);
                     V_temp2(i,:,zz,ee)=V_k_bar_polyfit'; % make sure the dimension 
                     end
                 end
         end

                 


     % @core 

                 % try to do the optimal search for k 
      for j=1:n_K
                     % get interpolation of k
                     cubic_fit_g0=spline(k_2,V_temp2(n_k2,j,1,1));
                     cubic_fit_g1=spline(k_2,V_temp2(n_k2,j,1,2));
                     cubic_fit_b0=spline(k_2,V_temp2(n_k2,j,2,1));
                     cubic_fit_b1=spline(k_2,V_temp2(n_k2,j,2,2));
                     lin_V_temp =V_temp2(n_k1,:,:,:);
                     
            for zz=1:2
                for ee=1:2
                    for i=1:n_k
                     % no interplation 
                     
                        
                        
                     % the optimal serach function to search best k'  for
                     % each k and K_bar
                     f_candi=@(x)bellman(x,k(i),K_bar(j),j,k_1,lin_V_temp,cubic_fit_g0,cubic_fit_g1,cubic_fit_b0,cubic_fit_b1,zz,ee,PP);

                     if k(i)<=k_2(1)
                         upper_bound=1.3*k(i);
                         lower_bound=0;
                     else if k(i)>k_2(1)
       
                         upper_bound=min(1.2*k(i),k(n_k));
                         lower_bound=0.5*k(i);
                         end

                     end
%                      
                     [k_tt,fval]=fminbnd(f_candi,lower_bound,upper_bound);
%                      %or we can use fminbnd(f_candi,max(0,k(i)-5), min(k(n_k)+5,2*k(i)) )
                     if k_tt<0
                         k_tt=0;
                     end
                     
                     if abs(fval)>10000 & (k_tt >0)
                         for iii=1:6
                         upper_bound=k(i)+k(i)*0.1^iii;
                         lower_bound=0.4*k(i);
                         [k_tt,fval]=fminbnd(f_candi,lower_bound,upper_bound);
                         if abs(fval)<10000
                             break
                         end
                             
                         end
                     end
                    
                     
                     temp_Val=-bellman(k_tt,k(i),K_bar(j),j,k_1,lin_V_temp,cubic_fit_g0,cubic_fit_g1,cubic_fit_b0,cubic_fit_b1,zz,ee,PP);

                     VV(i,j,zz,ee)=1*temp_Val+0.0*V_temp(i,j,zz,ee);

                     k_opt_t(i,j,zz,ee)=1*k_tt+0*k_opt_t(i,j,zz,ee);

                     
                     end % end of i
                 end % end of ee
                 
               
        
             end  % end of zz
     end   % end of j
     
     % finishing the loop for state k and theta
     % since the value of value function is slower for convergence (the interpolation for K_bar actually let it hard to converge! )
     %  just to see if decision rule policy function can be stable or not 
     diff=(k_opt_t-k_opt);
     diff2=(VV-V_temp);
     
     if mean(sqrt(diff.^2)) <= toler
         break
     else
         % so here if the diff exceeds the tolerance, then do a replacement
         % and go back to the top of the loop
         V_temp=VV;
         k_opt=k_opt_t;
%          never touch the state space value it is the fixed          
%          K_bar=K_bar_t;
%          k=k_t;
     end
     
 end
 toc
 fprintf('iteration time t is %d', t)
 %% 
 % when the VFI is done, we get 
 % VV the value function
 % k the current individual capital
 % k_t the nex period capital 
 % K_bar the current aggregate capital
 % K_bar_t the next period aggregate capital 
 
 % now we need to compute more precisely decision rule
 % firstly, to expand the value function according to k, K_bar space by
 % interpolation
 % secondly, run @core again to get policy function
 
 % policy function set current state space

 nn_k=400;
 k_policy2=linspace(0.1,lambda*K_bar_h,nn_k/2);
 k_policy1=linspace(0,0.095,nn_k/2);

 k_policy=[k_policy1,k_policy2]';
 k_p1=k_policy1';
 k_p2=k_policy2';
 nn_kk=length(k_policy);
 
 
  
  
 nn_K=50;
 K_policy=linspace(K_bar_l,K_bar_h,nn_K)';
 nn_KK=length(K_policy);
 
 
 % generate intermediate value
 V_new=zeros(nn_kk,nn_KK,n_z,n_e);
 V_new_temp =zeros(n_k,nn_KK,n_z,n_e);
 
 % policy decision rule
 decision_rule=zeros(nn_kk,nn_KK,n_z,n_e);
 
 
 % interpolation for vlaue function 
 [mesh_K,mesh_k]=meshgrid(K_bar,k);
 [mesh_K_policy,mesh_k_policy]=meshgrid(K_policy,k_policy);
  for zz = 1:2
     for ee = 1:2
        % the X is in the second Y is in the first
        V_new(:,:,zz,ee) = interp2(mesh_K,mesh_k,VV(:,:,zz,ee),mesh_K_policy,mesh_k_policy);
 
     end
  end
  
 
 

 % @core

for j=1:nn_KK
              % get interpolation of k
         cubic_fit_g0=spline(k_p2,V_new(nn_kk/2+1:end,j,1,1));
         cubic_fit_g1=spline(k_p2,V_new(nn_kk/2+1:end,j,1,2));
         cubic_fit_b0=spline(k_p2,V_new(nn_kk/2+1:end,j,2,1));
         cubic_fit_b1=spline(k_p2,V_new(nn_kk/2+1:end,j,2,2));
         lin_V_temp =V_new(1:nn_kk/2,:,:,:);
         
     for zz=1:2
        for ee=1:2
         % try to do the optimal search for k
             for i=1:nn_kk
                 
                 % the optimal serach function to search best k'  for
                 % each k and K_bar
                 f_candi=@(x)bellman(x,k_policy(i),K_policy(j),j,k_1,lin_V_temp,cubic_fit_g0,cubic_fit_g1,cubic_fit_b0,cubic_fit_b1,zz,ee,PP);
%                  [k_tt,fval]=fminsearch(f_candi,k_policy(i));


                    if k_policy(i)<=k_2(1)
                         upper_bound=1.3*k_policy(i);
                         lower_bound=0;
                     else if k_policy(i)>k_2(1)
       
                         upper_bound=min(1.2*k_policy(i),k_policy(end));
                         lower_bound=0.5*k_policy(i);
                         end

                     end
%                      
                     [k_tt,fval]=fminbnd(f_candi,lower_bound,upper_bound);
                     if k_tt<0
                         k_tt=0;
                     end
                     
                     if abs(fval)>10000 & k_tt >0
                         for iii=1:6
                         upper_bound=k_policy(i)+k_policy(i)*0.1^iii;
                         lower_bound=k_policy(i)-k_policy(i)*0.5^iii;
                         [k_tt,fval]=fminbnd(f_candi,lower_bound,upper_bound);
                         if abs(fval)<10000
                             break
                         end
                             
                         end
                     end
                 decision_rule(i,j,zz,ee)=k_tt;
                 
             end % end of j
         end % end of i
         
         
         
     end  % end of ee
 end   % end of zz
 
 
 
 
 
 
%load test
% simulation 
%% simulation 
% length of simulation data
% NOTE that z = 1(good ) 2(bad) e= 1(unemployment) 2(employment) 
flag=1;
T_disgard=1000;
T=11000;
N=5000;
% generate the aggregate shock of z
[PP,Pi_ss,series_state]=transition_matrix(flag,T);
U_state=[u_g,u_b];
Simu_matrix=zeros(N,T);

Simu_matrix(:,1)=randi([1 2],N,1);
temp_random_e_shock=rand(N,T);
for t=2:T
    pre_z=series_state(t-1);
    now_z=series_state(t);
    ore_e=Simu_matrix(:,t-1);
    rows=(pre_z-1)*2+ore_e;
    Simu_matrix(:,t)=1+1*(temp_random_e_shock(:,t)>(PP(rows,(now_z-1)*2+1)./Pi_ss(pre_z,now_z)));
    % check if it satisfies u_g=0.04 u_b=0.1
    % if not turn randomly 
%     if abs(sum(Simu_matrix(:,t)-1)/N-U_state(now_z))>0.0001
%         if sum(Simu_matrix(:,t)-1)<(1-U_state(now_z))*N  % < work not enough
%             num=(1-U_state(now_z))*N-sum(Simu_matrix(:,t)-1);
%             % find 1 in Simu_matrix and randomly turn to 2 
%             
%         end
%     end
        
end


% assuming we get the simulation series
% use the interpolation to locate each period and each individual's captial
% and aggregate capital 
% meshgrid [mesh_k_policy,mesh_K_policy]

% get initial steady state the steady state 
initial_k=K_bar_g;
initial_K=K_bar_g;

Simu_k=zeros(N,T);
Simu_K=zeros(T,1);
Simu_Kt=zeros(T,1);
% initial value
Simu_k(:,1)=initial_k;
Simu_K(1)=initial_K;

cur_z=series_state(1);


for t=2:T
    % get previous aggregate shock 
   pre_z=series_state(t-1);
   % this is empolyment project 
   temp_empoly=find(Simu_matrix(:,t-1)==2);
   [mesh_sim_K,mesh_sim_k]=meshgrid(Simu_K(t-1),Simu_k(temp_empoly,t-1));
   Simu_k(temp_empoly,t)=interp2(mesh_K_policy,mesh_k_policy,decision_rule(:,:,pre_z,2),mesh_sim_K,mesh_sim_k);
   % this is unempolyment project
   temp_empoly=find(Simu_matrix(:,t-1)==1);
   [mesh_sim_K,mesh_sim_k]=meshgrid(Simu_K(t-1),Simu_k(temp_empoly,t-1));
   Simu_k(temp_empoly,t)=interp2(mesh_K_policy,mesh_k_policy,decision_rule(:,:,pre_z,1),mesh_sim_K,mesh_sim_k);
   
   Simu_K(t)=mean(Simu_k(:,t));
    
    
end

Simu_k=Simu_k(:,1000+1:end);
Simu_K=Simu_K(1000+1:end,1);
series_state=series_state(1000+1:end);

good_time=find(series_state(1:end-1)==1);
bad_time=find(series_state(1:end-1)==2);

good_time1=good_time+1;
% regression one 
simu_x_g=log(Simu_K(good_time));
simu_y_g=log(Simu_K(good_time+1));

simu_x_b=log(Simu_K(bad_time));
simu_y_b=log(Simu_K(bad_time+1));

% regreesion
[a,bint,r_a,~,stats] = regress(simu_y_g,[ones(size(simu_x_g)),simu_x_g]);
a

[b,bint,r_b,~,stats2] = regress(simu_y_b,[ones(size(simu_x_b)),simu_x_b]);

b

% check 

residual=mean(sqrt([H(1,:)-a',H(2,:)-b'].^2));

residual

fprintf('the good time a_0 a_1 and R^2 is %0.4f, %0.4f, %0.4f \n', a(1),a(2),stats(1) )

fprintf('the bad   time b_0 b_1 and R^2 is %0.4f, %0.4f, %0.4f  \n', b(1),b(2),stats2(1) )


fprintf('the difference between simulated and assumption parameter is %0.4f \n', residual )



%% draw the graph 
% for individual capital 
figure
plot(k,k_opt_t(:,3,1,1),linspace(0,40,10),linspace(0,40,10))
hold on 
plot(k,k_opt_t(:,3,1,2)) 
xlabel('Today individual capital') % x-axis label
ylabel('Tomorrow individual capital') % y-axis label
title('An individual agent�s decision rules, Good Aggregate State')

% for aggregate capital 
KK_g=linspace(10,12.5,40);
KK_b=linspace(10,12.5,40);

KK_g_t=exp(a(1)+a(2)*log(KK_g));
KK_b_t=exp(b(1)+b(2)*log(KK_b));

figure
plot(KK_g,KK_g_t,linspace(10,12.5,10),linspace(10,12.5,10))
hold on 
plot(KK_b,KK_b_t)
xlabel('Today aggregate capital') % x-axis label
ylabel('Tomorrow aggregate capital') % y-axis label
title('Tomorrow�s vs. today�s aggregate capital (benchmark model)')


