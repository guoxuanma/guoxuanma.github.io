% simulation 
%% simulation 
% length of simulation data
% NOTE that z = 1(good ) 2(bad) e= 1(unemployment) 2(employment) 
flag=1;
T_disgard=1000;
T=11000;
N=5000;
% generate the aggregate shock of z
[PP,Pi_ss,series_state]=transition_matrix(flag,T);
U_state=[u_g,u_b];
Simu_matrix=zeros(N,T);

Simu_matrix(:,1)=randi([1 2],N,1);
temp_random_e_shock=rand(N,T);
for t=2:T
    pre_z=series_state(t-1);
    now_z=series_state(t);
    ore_e=Simu_matrix(:,t-1);
    rows=(pre_z-1)*2+ore_e;
    Simu_matrix(:,t)=1+1*(temp_random_e_shock(:,t)>(PP(rows,(now_z-1)*2+1)./Pi_ss(pre_z,now_z)));
    % check if it satisfies u_g=0.04 u_b=0.1
    % if not turn randomly 
%     if abs(sum(Simu_matrix(:,t)-1)/N-U_state(now_z))>0.0001
%         if sum(Simu_matrix(:,t)-1)<(1-U_state(now_z))*N  % < work not enough
%             num=(1-U_state(now_z))*N-sum(Simu_matrix(:,t)-1);
%             % find 1 in Simu_matrix and randomly turn to 2 
%             
%         end
%     end
        
end


% assuming we get the simulation series
% use the interpolation to locate each period and each individual's captial
% and aggregate capital 
% meshgrid [mesh_k_policy,mesh_K_policy]

% get initial steady state the steady state 
initial_k=K_bar_g;
initial_K=K_bar_g;

Simu_matrix=Simu_matrix(:,100:end);
series_state=series_state(100:end);
T=length(Simu_matrix);

Simu_k=zeros(N,T);
Simu_K=zeros(T,1);

% initial value
Simu_k(:,1)=initial_k;
Simu_K(1)=initial_K;

for t=2:T
   pre_z=series_state(t-1);
   % this is empolyment project 
   temp_empoly=find(Simu_matrix(:,t)==2);
   [mesh_sim_K,mesh_sim_k]=meshgrid(Simu_K(t-1),Simu_k(temp_empoly,t-1));
   Simu_k(temp_empoly,t)=interp2(mesh_K_policy,mesh_k_policy,decision_rule(:,:,pre_z,2),mesh_sim_K,mesh_sim_k);
   % this is unempolyment project
   temp_empoly=find(Simu_matrix(:,t)==1);
   [mesh_sim_K,mesh_sim_k]=meshgrid(Simu_K(t-1),Simu_k(temp_empoly,t-1));
   Simu_k(temp_empoly,t)=interp2(mesh_K_policy,mesh_k_policy,decision_rule(:,:,pre_z,1),mesh_sim_K,mesh_sim_k);
   
   Simu_K(t)=mean(Simu_k(:,t));
    
    
end

Simu_k=Simu_k(:,900+1:end);
Simu_K=Simu_K(900+1:end,1);
series_state=series_state(900+1:end);

good_time=find(series_state(1:end-1)==1);
bad_time=find(series_state(1:end-1)==2);

good_time1=good_time+1;
% regression one 
simu_x_g=log(Simu_K(good_time));
simu_y_g=log(Simu_K(good_time+1));

simu_x_b=log(Simu_K(bad_time));
simu_y_b=log(Simu_K(bad_time+1));

% regreesion
[a,bint,r_a] = regress(simu_y_g,[ones(size(simu_x_g)),simu_x_g]);

a

[b,bint,r_b] = regress(simu_y_b,[ones(size(simu_x_b)),simu_x_b]);

b

% check 


residual=sum(sqrt((reshape(H,4,1)-[a;b]).^2));
residual

% 
% % draw pic
% k=12;
% cubic_fit_g0=spline(k,V_temp2(:,4,1,1));
% cubic_fit_g1=spline(k,V_temp2(:,4,1,2));
% cubic_fit_b0=spline(k,V_temp2(:,4,2,1));
% cubic_fit_b1=spline(k,V_temp2(:,4,2,2));
% kt=1:0.02:10;
% y=zeros(1,length(kt));
% for ii=1:length(kt)
%     y(ii)=-bellman(kt(ii),12,K_bar(4),cubic_fit_g0,cubic_fit_g1,cubic_fit_b0,cubic_fit_b1,1,2,PP);
%     
% end
% 
% plot(kt,y)
